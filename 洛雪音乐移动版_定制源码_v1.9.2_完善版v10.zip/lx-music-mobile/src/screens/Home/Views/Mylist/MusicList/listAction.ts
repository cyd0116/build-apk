import { Alert } from 'react-native'
import { addListMusics, removeListMusics, updateListMusicPosition, updateListMusics } from '@/core/list'
import { getLocalFilePaths, removeLocalFiles } from '@/core/music/downloadManager'
import { playList, playListById, playNext } from '@/core/player/player'
import { addTempPlayList } from '@/core/player/tempPlayList'
import settingState from '@/store/setting/state'
import { similar, sortInsert, toOldMusicInfo } from '@/utils'
import { confirmDialog, openUrl, shareMusic, toast } from '@/utils/tools'
import { addDislikeInfo, hasDislike } from '@/core/dislikeList'
import playerState from '@/store/player/state'

import type { SelectInfo } from './ListMenu'
import { type Metadata } from '@/components/MetadataEditModal'
import musicSdk from '@/utils/musicSdk'
import { getListMusicSync } from '@/utils/listManage'
import { clearMusicUrlByMusic } from '@/utils/data'

export const handlePlay = (listId: SelectInfo['listId'], index: SelectInfo['index']) => {
  void playList(listId, index)
}
export const handlePlayLater = (listId: SelectInfo['listId'], musicInfo: SelectInfo['musicInfo'], selectedList: SelectInfo['selectedList'], onCancelSelect: () => void) => {
  if (selectedList.length) {
    addTempPlayList(selectedList.map(s => ({ listId, musicInfo: s })))
    onCancelSelect()
  } else {
    addTempPlayList([{ listId, musicInfo }])
  }
}

/**
 * 定制功能：删除歌单内歌曲时对本地文件的处理，遵循设置项
 * 「list.deleteLocalFileMode」：ask（每次询问）/ always（总是同时删除，删除前二次确认）/ never（仅从歌单移除）
 */
export const handleRemove = (listId: SelectInfo['listId'], musicInfo: SelectInfo['musicInfo'], selectedList: SelectInfo['selectedList'], onCancelSelect: () => void) => {
  const musics = selectedList.length ? selectedList : [musicInfo]
  const ids = musics.map(m => m.id)

  void getLocalFilePaths(musics).then(entries => {
    const doRemove = async(deleteFiles: boolean) => {
      if (deleteFiles && entries.length) {
        try {
          const num = await removeLocalFiles(entries)
          if (num) toast(global.i18n.t('list_remove_file_success_tip', { num }))
        } catch (err: any) {
          toast(global.i18n.t('list_remove_file_fail_tip', { msg: err?.message ?? String(err) }))
        }
      }
      await removeListMusics(listId, ids)
      onCancelSelect()
    }

    /** 删除前确认：批量删除、或「总是同时删除」模式下每次删除都要弹确认界面 */
    const confirmRemove = (deleteFiles: boolean) => {
      const num = musics.length
      const message = deleteFiles && entries.length
        ? global.i18n.t('list_remove_confirm_with_file_tip', { num, files: entries.length })
        : num > 1
          ? global.i18n.t('list_remove_music_multi_tip', { num })
          : global.i18n.t('list_remove_tip', { name: musics[0].name })
      void confirmDialog({
        message,
        confirmButtonText: global.i18n.t('list_remove_tip_button'),
        cancelButtonText: global.i18n.t('dialog_cancel'),
        bgClose: false,
      }).then(isRemove => {
        if (!isRemove) return
        void doRemove(deleteFiles)
      })
    }

    const mode = settingState.setting['list.deleteLocalFileMode'] ?? 'ask'

    // 每次询问：检测到本地文件时给出三选一弹窗（本身就是确认界面）
    if (mode == 'ask' && entries.length) {
      Alert.alert(
        global.i18n.t('list_remove_music_title'),
        global.i18n.t('list_remove_with_file_tip', { num: entries.length }),
        [
          // 定制功能：确认类按钮在左、取消固定在最右；一律以「确认 / 取消」表述
          { text: `${global.i18n.t('confirm')} · ${global.i18n.t('list_remove_only_from_list')}`, onPress: () => { void doRemove(false) } },
          { text: `${global.i18n.t('confirm')} · ${global.i18n.t('list_remove_and_delete_file')}`, onPress: () => { void doRemove(true) } },
          { text: global.i18n.t('cancel') },
        ],
        { cancelable: true },
      )
      return
    }

    // 总是同时删除：无论单选/多选，删除前都先弹出确认界面
    if (mode == 'always') {
      confirmRemove(entries.length > 0)
      return
    }

    // 仅从歌单移除 / 每次询问且无本地文件：批量删除才确认，单首直接移除
    if (musics.length > 1) confirmRemove(false)
    else void doRemove(false)
  })
}


export const handleUpdateMusicPosition = (position: number, listId: SelectInfo['listId'], musicInfo: SelectInfo['musicInfo'], selectedList: SelectInfo['selectedList'], onCancelSelect: () => void) => {
  if (selectedList.length) {
    void updateListMusicPosition(listId, position, selectedList.map(s => s.id))
    onCancelSelect()
  } else {
    // console.log(listId, position, [musicInfo.id])
    void updateListMusicPosition(listId, position, [musicInfo.id])
  }
}

export const handleUpdateMusicInfo = (listId: SelectInfo['listId'], musicInfo: LX.Music.MusicInfoLocal, newInfo: Metadata) => {
  void updateListMusics([
    {
      id: listId,
      musicInfo: {
        ...musicInfo,
        name: newInfo.name,
        singer: newInfo.singer,
        meta: {
          ...musicInfo.meta,
          albumName: newInfo.albumName,
        },
      },
    },
  ])
}


export const handleShare = (musicInfo: SelectInfo['musicInfo']) => {
  shareMusic(settingState.setting['common.shareType'], settingState.setting['download.fileName'], musicInfo)
}


export const searchListMusic = (list: LX.Music.MusicInfo[], text: string) => {
  const fullMathNameResults = new Set<LX.Music.MusicInfo>()
  const fullMathSingerResults = new Set<LX.Music.MusicInfo>()
  const fullMathAlbumResults = new Set<LX.Music.MusicInfo>()
  const textLower = text.toLowerCase()
  for (const mInfo of list) {
    if (mInfo.name?.toLowerCase().includes(textLower)) {
      fullMathNameResults.add(mInfo)
    } else if (mInfo.singer?.toLowerCase().includes(textLower)) {
      fullMathSingerResults.add(mInfo)
    } else if (mInfo.meta.albumName?.toLowerCase().includes(textLower)) {
      fullMathAlbumResults.add(mInfo)
    }
  }
  let result: LX.Music.MusicInfo[] = []
  let rxp = new RegExp(text.split('').map(s => s.replace(/[.*+?^${}()|[\]\\]/, '\\$&')).join('.*') + '.*', 'i')
  for (const mInfo of list) {
    if (fullMathNameResults.has(mInfo) || fullMathSingerResults.has(mInfo) || fullMathAlbumResults.has(mInfo)) continue

    const str = `${mInfo.name}${mInfo.singer}${mInfo.meta.albumName ? mInfo.meta.albumName : ''}`
    if (rxp.test(str)) result.push(mInfo)
  }

  const sortedList: Array<{ num: number, data: LX.Music.MusicInfo }> = []

  for (const mInfo of result) {
    sortInsert(sortedList, {
      num: similar(text, `${mInfo.name}${mInfo.singer}${mInfo.meta.albumName ? mInfo.meta.albumName : ''}`),
      data: mInfo,
    })
  }
  return [
    ...fullMathNameResults.values(),
    ...fullMathSingerResults.values(),
    ...fullMathAlbumResults.values(),
    ...sortedList.map(item => item.data).reverse(),
  ]
}

export const handleShowMusicSourceDetail = async(minfo: SelectInfo['musicInfo']) => {
  const url = musicSdk[minfo.source as LX.OnlineSource]?.getMusicDetailPageUrl(toOldMusicInfo(minfo))
  if (!url) return
  void openUrl(url)
}

export const clearMusicUrl = async(musicInfo: SelectInfo['musicInfo']) => {
  try {
    await clearMusicUrlByMusic(musicInfo)
  } catch (error) {
    toast(global.i18n.t('list_remove_cache_fail_tip', { msg: (error as Error).message }))
    return
  }
  toast(global.i18n.t('list_remove_cache_success_tip'))
}


export const handleDislikeMusic = async(musicInfo: SelectInfo['musicInfo']) => {
  const confirm = await confirmDialog({
    message: musicInfo.singer ? global.i18n.t('lists_dislike_music_singer_tip', { name: musicInfo.name, singer: musicInfo.singer }) : global.i18n.t('lists_dislike_music_tip', { name: musicInfo.name }),
    cancelButtonText: global.i18n.t('cancel_button_text_2'),
    confirmButtonText: global.i18n.t('confirm_button_text'),
    bgClose: false,
  })
  if (!confirm) return
  await addDislikeInfo([{ name: musicInfo.name, singer: musicInfo.singer }])
  toast(global.i18n.t('lists_dislike_music_add_tip'))
  if (hasDislike(playerState.playMusicInfo.musicInfo)) {
    void playNext(true)
  }
}

export const handleToggleSource = async(listId: string, musicInfo: LX.Music.MusicInfo, toggleMusicInfo: LX.Music.MusicInfoOnline) => {
  const list = getListMusicSync(listId)
  const oldId = musicInfo.id
  let oldIdx = list.findIndex(m => m.id == oldId)
  if (oldIdx < 0) {
    void addListMusics(listId, [toggleMusicInfo], settingState.setting['list.addMusicLocationType'])
    return true
  }
  const id = toggleMusicInfo.id
  const index = list.findIndex(m => m.id == id)
  const removeIds = [oldId]
  if (index > -1) {
    if (!await confirmDialog({
      message: global.i18n.t('music_toggle__duplicate_tip'),
      cancelButtonText: global.i18n.t('dialog_cancel'),
      confirmButtonText: global.i18n.t('dialog_confirm'),
    })) return false
    removeIds.push(id)
  }
  void removeListMusics(listId, removeIds).then(async() => {
    await addListMusics(listId, [toggleMusicInfo], 'bottom')
    if (index != -1 && index < oldIdx) oldIdx--
    await updateListMusicPosition(listId, oldIdx, [id])
    if (playerState.playMusicInfo.listId == listId && playerState.playMusicInfo.musicInfo?.id == oldId) {
      void playListById(listId, toggleMusicInfo.id)
    }
  })
  return true
}
