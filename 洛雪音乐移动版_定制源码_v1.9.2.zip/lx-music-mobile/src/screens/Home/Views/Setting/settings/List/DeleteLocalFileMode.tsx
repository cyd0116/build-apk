import { memo, useMemo } from 'react'

import { StyleSheet, View } from 'react-native'

import SubTitle from '../../components/SubTitle'
import CheckBox from '@/components/common/CheckBox'
import { useSettingValue } from '@/store/setting/hook'
import { useI18n } from '@/lang'
import { updateSetting } from '@/core/common'
import Text from '@/components/common/Text'
import { useTheme } from '@/store/theme/hook'

type DeleteLocalFileMode = LX.AppSetting['list.deleteLocalFileMode']

const useActive = (id: DeleteLocalFileMode) => {
  const mode = useSettingValue('list.deleteLocalFileMode')
  return useMemo(() => mode == id, [mode, id])
}

const Item = ({ id, name }: { id: DeleteLocalFileMode, name: string }) => {
  const isActive = useActive(id)
  return <CheckBox marginRight={8} check={isActive} label={name} onChange={() => { updateSetting({ 'list.deleteLocalFileMode': id }) }} need />
}

/**
 * 定制功能：删除歌单歌曲时是否「同时删除本地歌曲文件」的默认行为
 * - 每次询问（默认）：保留原来的三选一弹窗
 * - 总是同时删除：不再询问，直接删除本地文件
 * - 仅从歌单移除：不删除本地文件，也不再询问
 */
export default memo(() => {
  const t = useI18n()
  const theme = useTheme()

  return (
    <SubTitle title={t('setting_delete_local_file')}>
      <View style={styles.list}>
        <Item id="ask" name={t('setting_delete_local_file_ask')} />
        <Item id="always" name={t('setting_delete_local_file_always')} />
        <Item id="never" name={t('setting_delete_local_file_never')} />
      </View>
      <Text size={11} color={theme['c-font-label']} style={styles.tip}>{t('setting_delete_local_file_tip')}</Text>
    </SubTitle>
  )
})

const styles = StyleSheet.create({
  list: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tip: {
    marginTop: 4,
  },
})
