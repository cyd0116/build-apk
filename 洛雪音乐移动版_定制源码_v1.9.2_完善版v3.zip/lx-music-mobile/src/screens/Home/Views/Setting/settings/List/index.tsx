import { memo } from 'react'

import Section from '../../components/Section'
import AddMusicLocationType from './AddMusicLocationType'
import IsClickPlayList from './IsClickPlayList'
import IsShowAlbumName from './IsShowAlbumName'
import IsShowInterval from './IsShowInterval'
import IsAutoAddToLove from './IsAutoAddToLove'
import IsAutoSortOnNewMusic from './IsAutoSortOnNewMusic'
import DownloadQuality from './DownloadQuality'
import DownloadDir from './DownloadDir'
import DeleteLocalFileMode from './DeleteLocalFileMode'

import { useI18n } from '@/lang'

export default memo(() => {
  const t = useI18n()

  return (
    <Section title={t('setting_list')}>
      <IsClickPlayList />
      <IsShowAlbumName />
      <IsShowInterval />
      <AddMusicLocationType />
      <IsAutoAddToLove />
      <IsAutoSortOnNewMusic />
      <DownloadQuality />
      <DownloadDir />
      <DeleteLocalFileMode />
    </Section>
  )
})
