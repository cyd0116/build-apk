# 洛雪音乐移动版 v1.9.2 定制源码｜本地构建 32 位 APK 详细教程

> 适用对象：`洛雪音乐移动版_定制源码_v1.9.2.zip`（基于官方 `lyswhut/lx-music-mobile` v1.9.2 修改的定制工程）
> 目标产物：`lx-music-mobile-v1.9.2-armeabi-v7a.apk`（**32 位 ARM / armeabi-v7a**，可直接安装到安卓手机）
> 预计耗时：首次约 15～40 分钟（要下载 Gradle、Maven 依赖、NDK 并编译 C++ 原生模块）；后续增量构建 3～10 分钟
> 磁盘要求：建议预留 **25 GB 以上**可用空间

---

## 目录

0. [先弄清要装哪些东西](#0-先弄清要装哪些东西)
1. [软件下载链接总表](#1-软件下载链接总表)
2. [安装与环境变量配置](#2-安装与环境变量配置)
3. [安装 Android SDK 组件](#3-安装-android-sdk-组件)
4. [解压源码并确认目录](#4-解压源码并确认目录)
5. [生成 release 签名（必须）](#5-生成-release-签名必须)
6. [锁定只构建 32 位](#6-锁定只构建-32-位)
7. [安装 npm 依赖](#7-安装-npm-依赖)
8. [（推荐）先构建 Debug 验证环境](#8推荐先构建-debug-验证环境)
9. [构建 32 位 Release APK](#9-构建-32-位-release-apk)
10. [产物验证与安装到手机](#10-产物验证与安装到手机)
11. [常见报错排查表](#11-常见报错排查表)
12. [国内网络加速（可选）](#12-国内网络加速可选)
13. [附录：一键脚本做了什么 / 改版本号 / 检查清单](#13-附录)

---

## 0. 先弄清要装哪些东西

下面这些版本号**不是随便写的**，全部来自本工程自身的配置文件，版本装错会直接构建失败：

| 组件 | 要求版本 | 依据（工程内文件） |
| --- | --- | --- |
| Node.js | `>= 18`，推荐 **20 LTS**（官方 CI 的构建测试用 20，`.nvmrc` 写的是 18） | `package.json` 的 `engines`、`build-test.yml` |
| npm | `>= 8.5.2`（随 Node 附带） | `package.json` |
| **JDK** | **必须是 17**（Android Gradle Plugin 8.6.1 的要求；官方 CI 用 Microsoft OpenJDK 17） | `.github/actions/setup/action.yml`、`android/build.gradle` |
| Android SDK Platform | **API 36**（`compileSdkVersion = 36`） | `android/build.gradle` |
| Android Build Tools | **35.0.0**（`buildToolsVersion = "35.0.0"`） | `android/build.gradle` |
| Android NDK | **26.1.10909125**（`ndkVersion`，务必精确） | `android/build.gradle` |
| CMake | **3.22.1**（C++ 原生模块需要） | 工程含 `react-native-quick-base64` 等 C++ 模块 |
| Gradle | **8.8**（`gradle-8.8-all.zip`，**由 wrapper 自动下载，不用手动装**） | `android/gradle/wrapper/gradle-wrapper.properties` |
| Git | 最新版即可，**必须能访问 GitHub** | `package.json` 里有 4 个 `github:lyswhut/...` 依赖 |
| Python 3 | 可选，仅 `build-32bit.sh` 一键脚本用到 | `build-32bit.sh` |
| Android Platform-Tools | 含 `adb`、`apksigner`，用于安装与校验 | 装机用 |

工程基本信息：React Native 0.73.11 / Hermes 开启 / 包名 `cn.toside.music.mobile` / `versionCode 79` / `minSdk 21` / `targetSdk 29`。

> ⚠️ **Windows 用户最重要的一条**：本工程含 C++ 原生模块，**Gradle 缓存目录、临时目录、源码所在路径都不能带中文或空格**。请把源码解压到类似 `D:\lx-music` 这种纯英文短路径，并按第 2 节设置 `GRADLE_USER_HOME`、`TEMP`、`TMP`。这是官方打包指南里点名的头号坑。

---

## 1. 软件下载链接总表

全部为官方站点。带「中国镜像」的优先用国内站点，下载更稳。

### 必需

| 软件 | 版本建议 | 官方下载链接 | 备注 |
| --- | --- | --- | --- |
| **Node.js** | 20 LTS（或 18 LTS） | https://nodejs.org/en/download <br> 中文页：https://nodejs.org/zh-cn/download <br> 历史版本：https://nodejs.org/dist/ | 选 `.msi` / `.pkg`，一路下一步即可；装完自带 npm |
| **Git** | 最新版 | https://git-scm.com/downloads <br> Windows 直链页：https://git-scm.com/download/win | **必装**，npm 要从 GitHub 拉 4 个依赖 |
| **JDK 17** | Microsoft Build of OpenJDK 17（与官方 CI 一致） | https://learn.microsoft.com/en-us/java/openjdk/download | 页面里展开 **OpenJDK 17**，选 Windows x64 `.msi` / macOS `.pkg` / Linux `.tar.gz` |
| **JDK 17（备选）** | Eclipse Temurin 17 LTS | https://adoptium.net/zh-CN/temurin/releases/?version=17 | 二选一即可，不要装 JDK 21 顶替 |
| **Android Studio**（推荐，含 SDK 管理器） | 最新稳定版 | 国际：https://developer.android.com/studio <br> **中国站（推荐）**：https://developer.android.google.cn/studio | 安装时勾选 Android SDK、Android SDK Platform、Android Virtual Device（可不装模拟器） |
| **仅命令行工具**（不装 Android Studio 时用） | 最新 commandlinetools | 同一页面下方「**仅限命令行工具 / Command line tools only**」区块：https://developer.android.google.cn/studio | 下载对应系统的 `commandlinetools-xxx_latest.zip`，内含 `sdkmanager` |
| **Android NDK** | **26.1.10909125**（r26b） | 下载页：https://developer.android.google.cn/ndk/downloads <br> 旧版本入口：页面内「不受支持的旧版本」 | **更推荐用 `sdkmanager "ndk;26.1.10909125"` 精确安装**（见第 3 节），不必手动下 zip |
| **Android SDK Platform-Tools**（adb） | 最新版 | https://developer.android.google.cn/studio/releases/platform-tools.html | 装了 Android Studio 就不用单独下，用 SDK 管理器装即可 |
| **Gradle 8.8** | 8.8 `all` 包 | 发布页：https://gradle.org/releases/ <br> 直链：https://services.gradle.org/distributions/gradle-8.8-all.zip | **正常情况不用下载**，`gradlew` 会自动拉；只在下载超时时手动下（见第 11 节） |

### 可选

| 软件 | 下载链接 | 用途 |
| --- | --- | --- |
| Python 3 | https://www.python.org/downloads/ | 只需运行一键脚本 `build-32bit.sh`（脚本里用 `python3` 改配置文件）；手工构建完全不需要 |
| 7-Zip | https://www.7-zip.org/ | Windows 解压 zip / 查看 APK 内部结构 |
| Git Bash | 随 Git for Windows 安装 | Windows 上运行 `.sh` 一键脚本 |
| 手机 USB 驱动 | 手机厂商官网 / Android Studio 的 SDK Manager → SDK Tools → **Google USB Driver** | `adb install` 需要 |

> 源码本身不在网上：用你已拿到的 `洛雪音乐移动版_定制源码_v1.9.2.zip`。

---

## 2. 安装与环境变量配置

### 2.1 安装顺序

```
Node.js → Git → JDK 17 → Android Studio（或仅命令行工具）→ 用 SDK Manager 装 SDK/NDK → 配环境变量 → 验证
```

安装后**重新打开**终端（PowerShell / Terminal），环境变量才会生效。

### 2.2 Windows（PowerShell，管理员或用户变量均可）

按 `Win + R` → 输入 `sysdm.cpl` → 「高级」→「环境变量」，在**用户变量**里新建/修改：

| 变量名 | 示例值 | 说明 |
| --- | --- | --- |
| `JAVA_HOME` | `C:\Program Files\Microsoft\jdk-17.0.xx-x64` | 指向 JDK 17 根目录（里面有 `bin\java.exe`） |
| `ANDROID_HOME` | `C:\Android\Sdk` | Android SDK 根目录 |
| `ANDROID_SDK_ROOT` | `C:\Android\Sdk` | 同上，两个都设更保险 |
| `GRADLE_USER_HOME` | `D:\gradle_home` | **纯英文**，Gradle 缓存 |
| `TEMP` | `D:\Temp` | **纯英文**，需提前建好该目录 |
| `TMP` | `D:\Temp` | 同上 |

在 `Path` 里追加：

```
%JAVA_HOME%\bin
%ANDROID_HOME%\platform-tools
%ANDROID_HOME%\cmdline-tools\latest\bin
```

也可以只在**每次构建前**临时设置（不用改系统变量）：

```powershell
$env:JAVA_HOME = "C:\Program Files\Microsoft\jdk-17.0.xx-x64"
$env:ANDROID_HOME = "C:\Android\Sdk"
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:GRADLE_USER_HOME = "D:\gradle_home"
$env:TEMP = "D:\Temp"
$env:TMP  = "D:\Temp"
New-Item -ItemType Directory -Force -Path "D:\Temp","D:\gradle_home" | Out-Null
```

### 2.3 macOS / Linux

编辑 `~/.zshrc`（macOS 默认）或 `~/.bashrc` / `~/.profile`：

```bash
export JAVA_HOME="/Library/Java/JavaVirtualMachines/microsoft-17.jdk/Contents/Home"   # 按实际路径改
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_USER_HOME="$HOME/.gradle"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
```

然后 `source ~/.zshrc`。macOS 可用 `/usr/libexec/java_home -V` 查 JDK 实际路径。

### 2.4 一键验证环境

```bash
node -v            # v20.x 或 v18.x
npm -v             # >= 8.5.2
git --version      # 必须能输出版本
java -version      # 必须显示 openjdk version "17.x"
javac -version     # javac 17.x
echo $ANDROID_HOME # Windows PowerShell 用: echo $env:ANDROID_HOME
sdkmanager --version
adb version
```

任何一项不对，先修好再往下走。

---

## 3. 安装 Android SDK 组件

### 3.1 用 Android Studio 图形界面（推荐新手）

打开 **Android Studio → Settings/Preferences → Appearance & Behavior → System Settings → Android SDK**：

- **SDK Platforms**：勾选 **Android API 36**（以及 Android 10 / API 29 可选，targetSdk 用得上）
- **SDK Tools**：勾选右下角 **Show Package Details**，然后选：
  - `Android SDK Build-Tools` → **35.0.0**
  - `NDK (Side by side)` → **26.1.10909125**（约 1 GB）
  - `CMake` → **3.22.1**
  - `Android SDK Platform-Tools`（adb）
  - `Android SDK Command-line Tools (latest)`
- 点 Apply 下载，然后接受许可协议。

### 3.2 用命令行工具（无图形界面 / CI 风格）

若只下了「仅命令行工具」zip，解压后**必须整理成如下目录结构**（这是 Android 官方要求）：

```
C:\Android\Sdk\                     ← 这就是 ANDROID_HOME
└── cmdline-tools\
    └── latest\
        ├── bin\        (sdkmanager.bat / sdkmanager)
        ├── lib\
        ├── NOTICE.txt
        └── source.properties
```

即：把解压出来的 `cmdline-tools` 里的内容**移动到新建的 `latest` 子目录**，再把整个 `cmdline-tools` 放到 SDK 根目录。

然后执行（Windows 用 `sdkmanager.bat`，macOS/Linux 用 `sdkmanager`）：

```bash
# 先接受所有许可（会问若干次，全部输 y）
sdkmanager --licenses

# 安装本工程精确需要的组件
sdkmanager "platform-tools" "platforms;android-36" "build-tools;35.0.0" "ndk;26.1.10909125" "cmake;3.22.1"

# 确认已安装项（--list 里带 "installed" 标记的就是已装组件）
sdkmanager --list
```

检查 NDK 目录是否存在：`$ANDROID_HOME/ndk/26.1.10909125`（Windows：`C:\Android\Sdk\ndk\26.1.10909125`）。

> 如果 Gradle 仍提示找不到 SDK，可在 `android/local.properties` 写一行（Windows 路径注意转义）：
> ```
> sdk.dir=C\:\\Android\\Sdk
> ```
> macOS/Linux：`sdk.dir=/Users/你/Android/Sdk`

---

## 4. 解压源码并确认目录

把 `洛雪音乐移动版_定制源码_v1.9.2.zip` 解压到**纯英文、无空格**的路径：

- Windows：`D:\lx-music\`
- macOS/Linux：`~/lx-music/`

解压后进入 `lx-music-mobile/`，应能看到这些关键文件：

```
lx-music-mobile/
├── package.json                  # 版本号 1.9.2 / versionCode 79
├── package-lock.json             # npm ci 必需，勿删
├── build-32bit.sh                # 一键构建脚本
├── BUILD_32BIT.md                # 简要构建说明
├── BUILD_TUTORIAL.md             # 本教程（已一并放入压缩包）
├── android/
│   ├── gradle.properties         # 第 30 行控制架构
│   ├── gradlew / gradlew.bat
│   ├── app/
│   │   ├── build.gradle
│   │   ├── debug.keystore        # Debug 用，已自带
│   │   └── lxmusic.keystore      # ← 第 5 节生成
│   └── keystore.properties       # ← 第 5 节生成
└── src/ ...
```

---

## 5. 生成 release 签名（必须）

`android/app/build.gradle` 的 `release` 构建会读取 `android/keystore.properties`，**没有这个文件会直接报错**。Debug 构建不需要。

在工程根目录执行（一次即可，以后一直复用同一份签名）：

```bash
cd lx-music-mobile

keytool -genkeypair -v \
  -keystore android/app/lxmusic.keystore \
  -alias lxmusic \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass lxmusic123456 -keypass lxmusic123456 \
  -dname "CN=LX Music Custom, OU=Custom, O=Custom, L=SZ, ST=GD, C=CN"
```

Windows PowerShell 请直接写成一行（PowerShell 续行用反引号 `` ` ``，CMD 批处理用 `^`），或复制 `build-32bit.sh` 里那条单行命令：

```powershell
keytool -genkeypair -v -keystore android/app/lxmusic.keystore -alias lxmusic -keyalg RSA -keysize 2048 -validity 10000 -storepass lxmusic123456 -keypass lxmusic123456 -dname "CN=LX Music Custom, OU=Custom, O=Custom, L=SZ, ST=GD, C=CN"
```

再新建文件 **`android/keystore.properties`**（与 `android/app/build.gradle` 同级目录 `android/` 下）：

```properties
storeFile=lxmusic.keystore
storePassword=lxmusic123456
keyAlias=lxmusic
keyPassword=lxmusic123456
```

要点：

- `storeFile` 是**相对 `android/app/` 目录**解析的，所以 `.keystore` 必须放在 `android/app/` 下；写绝对路径也可以（如 `D\:/lx-music/keystore/lxmusic.keystore`）。
- **请改成自己的密码**，并妥善备份 `.keystore`。以后升级安装同一个 App 必须用同一签名，否则会报 `INSTALL_FAILED_UPDATE_INCOMPATIBLE`，只能先卸载（会丢本地歌单数据）。
- 不要把 `keystore` 和密码提交到公开仓库。

另一种官方 CI 的做法是不建 `keystore.properties`，构建时用 `-P` 传参：

```bash
./gradlew assembleRelease \
  -PMYAPP_UPLOAD_STORE_FILE=lxmusic.keystore \
  -PMYAPP_UPLOAD_KEY_ALIAS=lxmusic \
  -PMYAPP_UPLOAD_STORE_PASSWORD=lxmusic123456 \
  -PMYAPP_UPLOAD_KEY_PASSWORD=lxmusic123456
```

---

## 6. 锁定只构建 32 位

打开 **`android/gradle.properties`**，把第 30 行：

```properties
reactNativeArchitectures=armeabi-v7a,arm64-v8a,x86,x86_64
```

改成：

```properties
reactNativeArchitectures=armeabi-v7a
```

也可以不改文件，构建时用命令行参数覆盖（一键脚本两种方式都做了）：

```
-PreactNativeArchitectures=armeabi-v7a
```

> `android/app/build.gradle` 里 `enableSeparateBuildPerCPUArchitecture = true` 且 `universalApk = true`，因此产物目录里**会同时出现** `...-armeabi-v7a.apk` 和 `...-universal.apk`。由于只 include 了 `armeabi-v7a`，两者都只含 32 位 so 库；请优先取 `-armeabi-v7a.apk` 安装，名字最明确。

---

## 7. 安装 npm 依赖

在工程根目录（`package.json` 所在目录）执行：

```bash
npm ci
```

说明与坑点：

- 工程自带 `package-lock.json`，请用 `npm ci`（可复现），不要 `npm install` 改锁文件。
- `package.json` 里有 4 个来自 GitHub 的依赖（`react-native-background-timer`、`react-native-file-system`、`react-native-local-media-metadata`、`react-native-track-player` 等均指向 `github:lyswhut/...`），**必须装了 Git 且能访问 `github.com`**，否则会报 `Error: Command failed: git clone ...` / `spawn git ENOENT`。
- 验证 GitHub 连通性：

  ```bash
  git ls-remote https://github.com/lyswhut/react-native-background-timer.git
  ```

- 国内网络可先把 npm 源切到镜像（GitHub 依赖仍走 Git，不受影响）：

  ```bash
  npm config set registry https://registry.npmmirror.com
  ```

- 若中途失败，删掉 `node_modules/` 后重新 `npm ci` 即可。

---

## 8. （推荐）先构建 Debug 验证环境

Debug 不需要签名，能快速暴露 JDK / NDK / SDK / 中文路径问题：

```bash
cd android
./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
```

首次会自动下载 **Gradle 8.8**（约 200 MB）和大量 Maven 依赖，并编译 C++ 原生模块。看到 `BUILD SUCCESSFUL` 就说明环境没问题，产物在 `android/app/build/outputs/apk/debug/`。

---

## 9. 构建 32 位 Release APK

### 方式 A：一键脚本（macOS / Linux / Windows 的 Git Bash）

```bash
cd lx-music-mobile
chmod +x build-32bit.sh
./build-32bit.sh
```

脚本会自动完成：生成自测签名 → 锁定 `armeabi-v7a` → `npm ci` → `./gradlew assembleRelease -PreactNativeArchitectures=armeabi-v7a` → 把 APK 复制到工程根目录。

> Windows 若没有 `python3`，脚本会失败；请改用手写方式 B（手工改 `gradle.properties` 即可，不影响结果）。

### 方式 B：手工执行（全平台通用，最稳妥）

```bash
cd lx-music-mobile
npm ci
cd android

# macOS / Linux
./gradlew assembleRelease -PreactNativeArchitectures=armeabi-v7a

# Windows PowerShell / CMD
gradlew.bat assembleRelease -PreactNativeArchitectures=armeabi-v7a
```

看到 `BUILD SUCCESSFUL` 即完成。想看详细日志可加 `--info`；编译失败重跑前可先 `./gradlew clean`。

---

## 10. 产物验证与安装到手机

### 10.1 找到 APK

```
android/app/build/outputs/apk/release/
├── lx-music-mobile-v1.9.2-armeabi-v7a.apk   ← 要的就是这个（32 位）
└── lx-music-mobile-v1.9.2-universal.apk
```

一键脚本还会把 `armeabi-v7a` 那份复制到工程根目录。

### 10.2 验证确实是 32 位、且签名有效

```bash
# 看 APK 里的 .so 目录，应只出现 lib/armeabi-v7a/
unzip -l lx-music-mobile-v1.9.2-armeabi-v7a.apk | grep "lib/"
# Windows 无 unzip：用 7-Zip 打开 APK，查看 lib\ 目录

# 校验签名（apksigner 在 $ANDROID_HOME/build-tools/35.0.0/）
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose lx-music-mobile-v1.9.2-armeabi-v7a.apk
# Windows PowerShell 用 apksigner.bat：
# & "$env:ANDROID_HOME\build-tools\35.0.0\apksigner.bat" verify --verbose .\lx-music-mobile-v1.9.2-armeabi-v7a.apk
```

### 10.3 安装

**用 adb（推荐）**：手机开启「开发者选项 → USB 调试」，数据线连电脑：

```bash
adb devices                       # 应列出设备，状态 device
adb install -r lx-music-mobile-v1.9.2-armeabi-v7a.apk
```

**或**：把 APK 传到手机，用文件管理器点击安装（需允许「安装未知来源应用」）。

### 10.4 装完后的功能确认（定制版）

- 首次启动会自动在「设置 → 基本设置 → 音乐来源 → 自定义源管理」里出现内置的「👖裤佬SVIP音源(二改整合版) v3.0.0」，并在未选择音源时自动启用。
- 下载默认保存到 **`Download/music`**；Android 11 及以上若要写入公共 Download 目录，需到「系统设置 → 应用 → 洛雪音乐 → 权限」开启「所有文件访问权限」，否则 App 会自动回退到应用私有目录并给出提示（工程 Manifest 已声明 `MANAGE_EXTERNAL_STORAGE`）。
- 设置 → 列表设置里可看到：自动加入「我的收藏」、下载音质默认选项、下载存储目录、删除时「同时删除本地歌曲文件」三态开关。

---

## 11. 常见报错排查表

| 现象 / 报错 | 原因 | 解决 |
| --- | --- | --- |
| `[CXX1429] error when building with cmake` / 各种 `cmake` 路径报错 | **Gradle 缓存或临时目录含中文/空格**，C++ 模块编译失败 | 把源码移到纯英文短路径；设置 `GRADLE_USER_HOME`、`TEMP`、`TMP` 到 `D:\gradle_home`、`D:\Temp`；重启终端后 `./gradlew clean` 重编 |
| `NDK is not configured` / `No version of NDK matched` | 没装或版本不对 | `sdkmanager "ndk;26.1.10909125" "cmake;3.22.1"`，确认 `$ANDROID_HOME/ndk/26.1.10909125` 存在 |
| `Android Gradle plugin requires Java 17` / `Unsupported class file major version` | JDK 版本不对（装了 8/11/21） | 装 JDK 17 并设 `JAVA_HOME`，`java -version` 确认 |
| `Failed to read key from keystore` / `keystore.properties (No such file or directory)` | 缺签名文件或路径/密码不对 | 按第 5 节重新生成；确认 `keystore.properties` 在 `android/` 下、`.keystore` 在 `android/app/` 下 |
| `java.lang.OutOfMemoryError` / Gradle daemon 被杀 | 内存不足 | 调大 `android/gradle.properties` 的 `org.gradle.jvmargs`（当前 `-Xmx4096m -XX:MaxMetaspaceSize=2048m`）；关闭其他程序；机器内存建议 ≥ 8 GB |
| `npm ci` 报 `git clone` / `spawn git ENOENT` / GitHub 超时 | 没装 Git 或访问不了 GitHub | 装 Git 并确认在 PATH；`git ls-remote https://github.com/lyswhut/react-native-background-timer.git` 测试；必要时配置网络代理 |
| Gradle 卡在 `Downloading https://services.gradle.org/distributions/gradle-8.8-all.zip` | 下载超时 | 手动下载 https://services.gradle.org/distributions/gradle-8.8-all.zip ，放到 `%GRADLE_USER_HOME%\wrapper\dists\gradle-8.8-all\<随机哈希目录>\` 内（保持 zip 不解压，gradlew 会自动解压），或临时把 `distributionUrl` 换成可访问的镜像 |
| `Failed to install the following Android SDK packages as some licences have not been accepted` | 未接受 SDK 许可 | `sdkmanager --licenses`，全部输入 `y` |
| `SDK location not found` | `ANDROID_HOME` 未生效 | 检查环境变量；或在 `android/local.properties` 写 `sdk.dir=...`（Windows 注意 `\:` 转义） |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | 手机上已装同包名但签名不同的版本（如官方版/别的定制版） | 先卸载旧版再装（**注意先备份歌单**）；或沿用旧签名 |
| `INSTALL_FAILED_NO_MATCHING_ABIS` | 装错包（用了 64 位专用包） | 确认装的是 `-armeabi-v7a.apk`；用 `unzip -l` 检查 `lib/armeabi-v7a/` |
| `Could not resolve com.facebook.react:react-android` / Maven 依赖拉取失败 | 网络不通 | 见第 12 节配置 Maven 镜像，或配代理 |
| 构建中途报磁盘满 / `No space left on device` | 空间不足 | 预留 25 GB；清理 `%GRADLE_USER_HOME%\caches`、`android/.cxx`、`android/app/build` |
| Windows 报路径过长 / 文件名语法错误 | 路径太深或含特殊字符 | 解压到 `D:\lx-music` 这类短路径 |

---

## 12. 国内网络加速（可选）

**只在出现下载超时/依赖解析失败时再做**，改坏了随时删掉即可。

**① npm 镜像**

```bash
npm config set registry https://registry.npmmirror.com
# 还原：npm config set registry https://registry.npmjs.org
```

注意：`github:` 前缀的依赖仍走 Git，需要 GitHub 可访问。

**② Maven / Google 仓库镜像**

在 `$GRADLE_USER_HOME/init.gradle`（Windows 为 `%GRADLE_USER_HOME%\init.gradle`）写入：

```groovy
allprojects {
    repositories {
        maven { url 'https://maven.aliyun.com/repository/google' }
        maven { url 'https://maven.aliyun.com/repository/public' }
        maven { url 'https://maven.aliyun.com/repository/central' }
        google()
        mavenCentral()
    }
}
```

**③ Gradle 发行包**

手动下载 `gradle-8.8-all.zip` 放进 wrapper 的 dists 缓存目录（见第 11 节），或把 `android/gradle/wrapper/gradle-wrapper.properties` 的 `distributionUrl` 临时指向可访问的镜像地址，构建完再改回。

---

## 13. 附录

### 13.1 一键脚本 `build-32bit.sh` 做了什么

1. 检查 `ANDROID_HOME` 和 `java` 是否存在；
2. 若没有 `android/keystore.properties`，用 `keytool` 生成自测签名并写好配置；
3. 用 Python 把 `android/gradle.properties` 的 `reactNativeArchitectures` 改成 `armeabi-v7a`；
4. `npm ci` 安装依赖；
5. `cd android && ./gradlew assembleRelease -PreactNativeArchitectures=armeabi-v7a`；
6. 把生成的 `armeabi-v7a` APK 复制到工程根目录并打印 `adb install` 命令。

脚本生成的自测签名密码是 `lxmusic123456`，**仅供自测**；正式分发请按第 5 节自建签名并修改密码。

### 13.2 想改版本号 / 应用名

版本号在根目录 `package.json`：`version`（版本名，如 `1.9.2`）、`versionCode`（安卓版本码，当前 `79`）。Gradle 会自动读取它们给 APK 命名和定版本。**覆盖安装时 `versionCode` 必须比旧版大**。

### 13.3 最终检查清单

- [ ] 源码路径纯英文、无空格
- [ ] `node -v` ≥ 18、`java -version` = 17、`git --version` 正常
- [ ] `ANDROID_HOME` / `JAVA_HOME` / `GRADLE_USER_HOME` / `TEMP` / `TMP` 已设且生效
- [ ] SDK 组件齐：`platforms;android-36`、`build-tools;35.0.0`、`ndk;26.1.10909125`、`cmake;3.22.1`、`platform-tools`
- [ ] `android/app/lxmusic.keystore` + `android/keystore.properties` 已生成
- [ ] `android/gradle.properties` 的 `reactNativeArchitectures=armeabi-v7a`
- [ ] `npm ci` 成功（GitHub 依赖能拉下来）
- [ ] `assembleRelease -PreactNativeArchitectures=armeabi-v7a` 输出 `BUILD SUCCESSFUL`
- [ ] APK 内只有 `lib/armeabi-v7a/`，`apksigner verify` 通过
- [ ] `adb install -r` 成功，手机能打开

---

## 合规提示

本项目为开源播放器，本身不含任何曲库；定制版内置的第三方音源脚本，其可用性与合法性由使用者自行判断。请仅用于个人学习、研究与本地构建自测，并遵守所在地区法律法规与音乐平台条款。本定制版非官方发布版本。

---

*教程基于工程内实际配置（`package.json` / `android/build.gradle` / `android/gradle.properties` / `gradle-wrapper.properties` / `.github/actions/setup/action.yml`）编写，并与官方 Android 打包指南的环境要求保持一致。*
