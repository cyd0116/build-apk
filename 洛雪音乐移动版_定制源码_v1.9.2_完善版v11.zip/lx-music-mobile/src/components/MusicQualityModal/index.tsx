import { forwardRef, useImperativeHandle, useRef, useState } from 'react'
import { ScrollView, TouchableOpacity, View } from 'react-native'
import Modal, { type ModalType } from '@/components/common/Modal'
import Text from '@/components/common/Text'
import { useI18n } from '@/lang'
import { useTheme } from '@/store/theme/hook'
import { useSettingValue } from '@/store/setting/hook'
import { createStyle } from '@/utils/tools'

export interface QualitySelectInfo {
  qualitys: LX.Quality[]
  musicInfo: LX.Music.MusicInfoOnline
  num: number
}

export interface MusicQualityModalType {
  show: (info: QualitySelectInfo, onSelect: (quality: LX.Quality) => void) => void
}

const qualityLabel = (quality: LX.Quality): string => {
  switch (quality) {
    case '320k': return '320k (HQ)'
    case 'flac': return 'FLAC (SQ)'
    case 'flac24bit': return 'FLAC 24bit'
    case 'ape': return 'APE'
    case 'wav': return 'WAV'
    default: return quality
  }
}

const qualitySize = (musicInfo: LX.Music.MusicInfoOnline, quality: LX.Quality): string => {
  const size = (musicInfo.meta as LX.Music.MusicInfoMeta_online)._qualitys?.[quality]?.size
  return size ? `  ·  ${size}` : ''
}

/**
 * 定制功能：下载前选择音质
 * 仅在设置里选择「每次询问」时才会出现；固定档位时下载直接开始，不再弹窗
 */
export default forwardRef<MusicQualityModalType, {}>((props, ref) => {
  const t = useI18n()
  const theme = useTheme()
  const defaultQuality = useSettingValue('download.quality')
  const preferred = defaultQuality == 'ask' ? null : defaultQuality
  const modalRef = useRef<ModalType>(null)
  const [visible, setVisible] = useState(false)
  const [info, setInfo] = useState<QualitySelectInfo | null>(null)
  const handlerRef = useRef<(quality: LX.Quality) => void>(() => {})

  useImperativeHandle(ref, () => ({
    show(newInfo, onSelect) {
      handlerRef.current = onSelect
      setInfo(newInfo)
      if (visible) modalRef.current?.setVisible(true)
      else {
        setVisible(true)
        requestAnimationFrame(() => {
          modalRef.current?.setVisible(true)
        })
      }
    },
  }))

  if (!visible) return null

  const hide = () => modalRef.current?.setVisible(false)
  const select = (quality: LX.Quality) => {
    hide()
    handlerRef.current(quality)
  }
  const hasDefault = !!info && preferred != null && info.qualitys.includes(preferred)

  return (
    <Modal ref={modalRef} bgColor="rgba(0,0,0,0.45)">
      <View style={styles.wrapper}>
        <View
          style={[styles.card, { backgroundColor: theme['c-content-background'], borderBottomColor: theme['c-font-label'] }]}
          onStartShouldSetResponder={() => true}
        >
          <Text style={styles.title} size={17}>{t('download_select_quality')}</Text>
          <Text style={styles.subTitle} size={12} color={theme['c-font-label']} numberOfLines={1}>
            {info?.musicInfo.name}{info && info.num > 1 ? `  +${info.num - 1}` : ''}
          </Text>
          <ScrollView style={styles.list}>
            {
              info?.qualitys.map(quality => (
                <TouchableOpacity
                  key={quality}
                  style={[styles.item, { borderBottomColor: theme['c-font-label'] }]}
                  onPress={() => { select(quality) }}
                >
                  <Text size={15} color={quality == preferred ? theme['c-primary'] : undefined}>
                    {qualityLabel(quality)}{qualitySize(info.musicInfo, quality)}
                    {quality == preferred ? `  ·  ${t('download_default_label')}` : ''}
                  </Text>
                </TouchableOpacity>
              ))
            }
          </ScrollView>
          {
            hasDefault && preferred
              ? (
                  <TouchableOpacity style={[styles.defaultBtn, { backgroundColor: theme['c-primary-background-active'] }]} onPress={() => { select(preferred) }}>
                    <Text size={14} color={theme['c-primary']}>{t('download_use_default')} · {qualityLabel(preferred)}</Text>
                  </TouchableOpacity>
                )
              : null
          }
          <TouchableOpacity style={styles.cancel} onPress={hide}>
            <Text size={15} color={theme['c-primary']}>{t('cancel')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  )
})

const styles = createStyle({
  wrapper: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 24,
    paddingRight: 24,
  },
  card: {
    width: '100%',
    maxHeight: '70%',
    borderRadius: 8,
    paddingTop: 16,
    paddingBottom: 8,
    paddingLeft: 16,
    paddingRight: 16,
  },
  title: {
    marginBottom: 6,
  },
  subTitle: {
    marginBottom: 10,
  },
  list: {
    flexGrow: 0,
  },
  item: {
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  defaultBtn: {
    marginTop: 10,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  cancel: {
    paddingTop: 14,
    paddingBottom: 8,
    alignItems: 'center',
  },
})
