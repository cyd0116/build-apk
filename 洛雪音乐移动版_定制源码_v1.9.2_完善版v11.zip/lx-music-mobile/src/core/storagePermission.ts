import { PermissionsAndroid } from 'react-native'

import { storageDataPrefix } from '@/config/constant'
import { getData, saveData } from '@/plugins/storage'

// 进程内只处理一次；避免热重载 / 重复回调导致多次弹框
let handled = false

/**
 * 定制功能：首次启动弹出系统标准的「允许应用访问存储」授权对话框
 * （READ_EXTERNAL_STORAGE / WRITE_EXTERNAL_STORAGE，工程 targetSdk 29，
 *   Manifest 已声明这两个权限）。
 *
 * - 只在首次启动发起一次：写入本地标记后，之后每次启动仅读一次标记即返回，
 *   不再弹框、不再重复写存储；
 * - 不预先做「已授权就短路」的检查，保证首次一定向系统发起授权请求；
 * - 无论用户允许 / 拒绝 / 请求异常，都记录标记，避免反复弹窗；
 * - 只请求权限，不附带任何应用内提示 / 许可页面。
 *
 * 说明：若系统此前已授予过这两项权限，Android 可能不再显示对话框而直接返回
 * 「已允许」——这是系统行为，请求本身仍已发起。用户此后也可在需要时通过
 * 下载、选择目录等功能再次触发工程原有的权限请求。
 */
export const requestStoragePermissionOnFirstLaunch = async(): Promise<void> => {
  if (handled) return
  if (await getData<boolean>(storageDataPrefix.storagePermissionFirstLaunch)) {
    handled = true
    return
  }
  handled = true

  try {
    await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
    ])
  } catch (err: any) {
    console.warn('[LX] request storage permission on first launch failed:', err?.message ?? String(err))
  } finally {
    // 只写这一次；此后启动不再弹框、不再写
    await saveData(storageDataPrefix.storagePermissionFirstLaunch, true)
  }
}
