/**
 * 定制功能：歌曲下载 / 已下载本地文件管理
 *
 * 说明：
 * - 复用了项目自带的 react-native-fs 与 react-native-file-system（@/utils/fs），不新增任何 npm 依赖；
 * - 默认保存到公共 Download/music 目录，目录可在「设置 → 列表设置 → 下载歌曲的存储目录」中更改；
 * - 写入公共目录前会申请存储权限，若目录不可写（常见于 Android 11+ 未授予所有文件访问权限），
 *   自动回退到应用私有目录，保证下载不中断；
 * - 歌曲 id 与本地文件绝对路径的对应关系保存在本地存储，
 *   因此更换下载目录后，旧文件仍能被「删除歌曲时同时删除本地文件」正确定位。
 */
import { LIST_IDS, storageDataPrefix } from '@/config/constant'
import { addListMusics, getListMusics } from '@/core/list'
import { getMusicUrl } from '@/core/music'
import { getData, saveData } from '@/plugins/storage'
import settingState from '@/store/setting/state'
import { downloadFile, existsFile, externalStorageDirectoryPath, mkdir, privateStorageDirectoryPath, unlink, writeFile } from '@/utils/fs'
import { formatMusicName, requestStoragePermission, toast } from '@/utils/tools'
import { applyListSortRule } from '@/utils/listSort'

type DownloadFileMap = Record<string, string[]>

export interface LocalFileEntry {
  musicInfo: LX.Music.MusicInfo
  paths: string[]
}

/** 音质由高到低的展示顺序 */
export const QUALITY_ORDER: LX.Quality[] = ['flac24bit', 'flac', 'ape', 'wav', '320k', '192k', '128k']

/** 默认下载目录：Download/music */
export const DEFAULT_DOWNLOAD_DIR = `${externalStorageDirectoryPath}/Download/music`
/** 公共目录不可写时的兜底目录（应用私有，无需权限） */
export const FALLBACK_DOWNLOAD_DIR = `${privateStorageDirectoryPath}/Music`
const AUDIO_EXTS = ['mp3', 'm4a', 'aac', 'flac', 'ape', 'wav', 'ogg', 'opus', 'wma', 'mp4']
const runningTasks = new Set<string>()

/** 当前生效的下载目录（设置值为空时使用默认 Download/music） */
export const getDownloadDir = (): string => (settingState.setting['download.dir'] || '').trim() || DEFAULT_DOWNLOAD_DIR

const getFileMap = async(): Promise<DownloadFileMap> => {
  return (await getData<DownloadFileMap>(storageDataPrefix.downloadFiles)) ?? {}
}

/**
 * 定制功能：列出下载记录里「在线歌曲 id -> 本地文件路径」的全部对应关系
 * 供「添加本地歌曲」增量导入使用，既能找到历史下载文件，也能避免和已自动加入歌单的在线版重复
 */
export const getDownloadedFileEntries = async(): Promise<Array<[string, string]>> => {
  const map = await getFileMap()
  const entries: Array<[string, string]> = []
  for (const [songId, paths] of Object.entries(map)) {
    for (const path of paths) entries.push([songId, path])
  }
  return entries
}

/** 列出下载记录里登记过的全部本地文件路径 */
export const getDownloadedFilePaths = async(): Promise<string[]> =>
  [...new Set((await getDownloadedFileEntries()).map(([, path]) => path))]

/** 逐级创建目录，兼容 FileSystem.mkdir 不递归的行为 */
const mkdirSafe = async(dir: string) => {
  const parts = dir.split('/').filter(Boolean)
  const absolute = dir.startsWith('/')
  let current = absolute ? '/' : ''
  for (const part of parts) {
    current = current == '/' ? `/${part}` : `${current}/${part}`
    try { await mkdir(current) } catch {}
  }
}

/** 写入一个临时文件再删除，真实探测目录是否可写 */
const canWrite = async(dir: string): Promise<boolean> => {
  const test = `${dir}/.lx_write_test`
  try {
    await writeFile(test, '')
    try { await unlink(test) } catch {}
    return true
  } catch {
    return false
  }
}

/**
 * 确认下载目录可用：
 * 公共目录先申请存储权限，创建或写入探测失败则回退到应用私有目录并提示
 */
const ensureDownloadDir = async(): Promise<string> => {
  const target = getDownloadDir()
  if (!target.startsWith(privateStorageDirectoryPath)) {
    try { await requestStoragePermission() } catch {}
  }
  try {
    await mkdirSafe(target)
    if (!(await canWrite(target))) throw new Error('directory is not writable')
    return target
  } catch {
    try { await mkdirSafe(FALLBACK_DOWNLOAD_DIR) } catch {}
    toast(global.i18n.t('download_dir_fallback_tip'), 'long')
    return FALLBACK_DOWNLOAD_DIR
  }
}

/** 读取某首在线歌曲实际可用的音质列表 */
export const getAvailableQualitys = (musicInfo: LX.Music.MusicInfoOnline): LX.Quality[] => {
  const qualitys = new Set<LX.Quality>()
  const meta = musicInfo.meta as LX.Music.MusicInfoMeta_online
  if (meta._qualitys) {
    for (const q of Object.keys(meta._qualitys) as LX.Quality[]) {
      if (meta._qualitys[q]) qualitys.add(q)
    }
  }
  if (!qualitys.size && meta.qualitys) {
    for (const q of meta.qualitys) qualitys.add(q.type)
  }
  return QUALITY_ORDER.filter(q => qualitys.has(q))
}

/**
 * 批量下载时取所有歌曲都支持的音质（交集）；
 * 若音源没有返回任何音质信息，则提供全部档位由用户选择，下载时由音源决定实际音质。
 */
export const getCommonQualitys = (list: LX.Music.MusicInfoOnline[]): LX.Quality[] => {
  if (!list.length) return []
  const qualityLists = list.map(getAvailableQualitys).filter(qs => qs.length)
  if (!qualityLists.length) return [...QUALITY_ORDER]
  return qualityLists.reduce((common, qs) => common.filter(q => qs.includes(q)))
}

/**
 * 定制功能：读取设置里的下载音质
 * - 设为 'ask'：返回 null，调用方弹出音质选择窗口
 * - 设为固定档位：直接返回可用档位，下载时不再弹窗；
 *   若该音源不支持所选档位，自动回退到不高于设定档位的最高可用档位
 */
export const resolveDownloadQuality = (list: LX.Music.MusicInfoOnline[]): LX.Quality | null => {
  const preferred = settingState.setting['download.quality']
  if (preferred == 'ask') return null
  const qualitys = getCommonQualitys(list)
  if (!qualitys.length) return preferred
  // 音源完全没返回音质信息时 getCommonQualitys 会列出全部档位，
  // 此时统一用最通用的 128k，避免直接请求不支持的高档位导致下载失败
  if (!list.some(m => getAvailableQualitys(m).length)) return '128k'
  if (qualitys.includes(preferred)) return preferred
  const start = QUALITY_ORDER.indexOf(preferred)
  const fallback = QUALITY_ORDER.slice(start < 0 ? 0 : start).find(q => qualitys.includes(q))
  return fallback ?? qualitys[qualitys.length - 1]
}

const sanitizeFileName = (name: string) => name.replace(/[\\/:*?"<>|\r\n\t]/g, '_').trim().slice(0, 110)

const guessExt = (quality: LX.Quality, url: string): string => {
  try {
    const path = url.split(/[?#]/)[0]
    const fileName = path.substring(path.lastIndexOf('/') + 1)
    const matched = /\.([a-zA-Z0-9]{2,4})$/.exec(fileName)
    if (matched && AUDIO_EXTS.includes(matched[1].toLowerCase())) return `.${matched[1].toLowerCase()}`
  } catch {}
  switch (quality) {
    case 'flac':
    case 'flac24bit': return '.flac'
    case 'ape': return '.ape'
    case 'wav': return '.wav'
    default: return '.mp3'
  }
}

const buildFilePath = async(musicInfo: LX.Music.MusicInfoOnline, quality: LX.Quality, url: string, dir: string): Promise<string> => {
  const base = sanitizeFileName(formatMusicName(settingState.setting['download.fileName'], musicInfo.name, musicInfo.singer)) || sanitizeFileName(musicInfo.id)
  const ext = guessExt(quality, url)
  let fileName = `${base}${ext}`
  let index = 1
  // 同一首歌允许下载多个音质，不覆盖已有文件
  while (await existsFile(`${dir}/${fileName}`)) {
    fileName = `${base} (${index++})${ext}`
  }
  return `${dir}/${fileName}`
}

const registerDownloadedFile = async(id: string, filePath: string) => {
  const map = await getFileMap()
  const paths = map[id] ?? []
  if (!paths.includes(filePath)) paths.push(filePath)
  map[id] = paths
  await saveData(storageDataPrefix.downloadFiles, map)
}

const addToLove = async(musicInfo: LX.Music.MusicInfoOnline) => {
  const loveList = await getListMusics(LIST_IDS.LOVE)
  if (loveList.some(m => m.id == musicInfo.id)) return
  await addListMusics(LIST_IDS.LOVE, [musicInfo], settingState.setting['list.addMusicLocationType'])
  // 定制功能：受设置页「新下载的歌曲自动按原排序规则排序」开关控制
  if (!settingState.setting['list.autoSortOnNewMusic']) return
  try {
    await applyListSortRule(LIST_IDS.LOVE)
  } catch (err) {
    console.warn('[LX] apply list sort rule failed:', err)
  }
}

const downloadMusic = async(musicInfo: LX.Music.MusicInfoOnline, quality: LX.Quality, dir: string) => {
  if (runningTasks.has(musicInfo.id)) {
    toast(global.i18n.t('download_running_tip'))
    return
  }
  runningTasks.add(musicInfo.id)
  let filePath = ''
  try {
    const url = await getMusicUrl({ musicInfo, quality, isRefresh: false })
    if (!url) throw new Error('empty music url')
    filePath = await buildFilePath(musicInfo, quality, url, dir)
    toast(global.i18n.t('download_start_tip', { name: musicInfo.name }))

    const { promise } = downloadFile(url, filePath, {
      connectionTimeout: 20_000,
      readTimeout: 60_000,
      progressInterval: 500,
    })
    const result = await promise
    if (result.statusCode != 200) throw new Error(`HTTP ${result.statusCode}`)
    if (!result.bytesWritten) throw new Error('empty file')

    await registerDownloadedFile(musicInfo.id, filePath)
    if (settingState.setting['download.autoAddToLove']) await addToLove(musicInfo)
    toast(global.i18n.t('download_success_tip', { name: filePath.substring(filePath.lastIndexOf('/') + 1) }))
  } catch (err: any) {
    if (filePath) {
      try { await unlink(filePath) } catch {}
    }
    toast(global.i18n.t('download_failed_tip', { msg: err?.message ?? String(err) }))
  } finally {
    runningTasks.delete(musicInfo.id)
  }
}

/** 串行下载，避免同一时刻发起大量连接 */
export const downloadMusics = async(list: LX.Music.MusicInfoOnline[], quality: LX.Quality) => {
  const dir = await ensureDownloadDir()
  for (const musicInfo of list) {
    await downloadMusic(musicInfo, quality, dir)
  }
}

/** 查找这些歌曲实际存在的本地文件（含应用下载的歌曲与已导入的本地歌曲） */
export const getLocalFilePaths = async(musics: LX.Music.MusicInfo[]): Promise<LocalFileEntry[]> => {
  const map = await getFileMap()
  const entries: LocalFileEntry[] = []
  for (const musicInfo of musics) {
    const paths = new Set<string>(map[musicInfo.id] ?? [])
    if (musicInfo.source == 'local') paths.add(musicInfo.meta.filePath)
    if (!paths.size) continue
    const existing: string[] = []
    for (const path of paths) {
      try {
        if (await existsFile(path)) existing.push(path)
      } catch {}
    }
    if (existing.length) entries.push({ musicInfo, paths: existing })
  }
  return entries
}

/** 删除本地文件并清理下载记录，返回成功删除的文件数 */
export const removeLocalFiles = async(entries: LocalFileEntry[]): Promise<number> => {
  const map = await getFileMap()
  let count = 0
  for (const { musicInfo, paths } of entries) {
    for (const path of paths) {
      try {
        await unlink(path)
        count++
      } catch {}
    }
    delete map[musicInfo.id]
  }
  await saveData(storageDataPrefix.downloadFiles, map)
  return count
}
