export const HOME_SCREEN = 'lxm.HomeScreen'
export const PLAY_DETAIL_SCREEN = 'lxm.PlayDetailScreen'
export const SONGLIST_DETAIL_SCREEN = 'lxm.SonglistDetailScreen'
export const COMMENT_SCREEN = 'lxm.CommentScreen'
export const SYNC_MODE_MODAL = 'lxm.SyncModeModal'
// export const SETTING_SCREEN = 'lxm.SettingScreen'
// export const TOAST_SCREEN = 'lxm.ToastScreen'

