import { memo, useMemo } from 'react'
import { StyleSheet, View } from 'react-native'

import SubTitle from '../../components/SubTitle'
import CheckBox from '@/components/common/CheckBox'
import Text from '@/components/common/Text'
import { useSettingValue } from '@/store/setting/hook'
import { updateSetting } from '@/core/common'
import { useI18n } from '@/lang'
import { useTheme } from '@/store/theme/hook'
import { TRY_QUALITYS_LIST } from '@/core/music/utils'

type DownloadQualitySetting = LX.AppSetting['download.quality']

const useActive = (id: DownloadQualitySetting) => {
  const quality = useSettingValue('download.quality')
  return quality == id
}

const Item = ({ id, name }: { id: DownloadQualitySetting, name: string }) => {
  const isActive = useActive(id)
  return <CheckBox marginRight={8} check={isActive} label={name} onChange={() => { updateSetting({ 'download.quality': id }) }} need />
}

/**
 * 定制功能：设置页选择下载音质
 * - 选中固定档位后，每次下载直接按该档位进行，不再弹出音质选择窗口；
 * - 选择「每次询问」则保留原来的下载前选择弹窗。
 */
export default memo(() => {
  const t = useI18n()
  const theme = useTheme()
  const qualityList = useMemo(() => {
    return [...TRY_QUALITYS_LIST, '128k'].reverse() as LX.Quality[]
  }, [])

  return (
    <SubTitle title={t('setting_download_default_quality')}>
      <View style={styles.list}>
        <Item id="ask" name={t('setting_download_quality_ask')} />
        {qualityList.map(q => <Item name={q} id={q} key={q} />)}
      </View>
      <Text size={11} color={theme['c-font-label']} style={styles.tip}>{t('setting_download_quality_tip')}</Text>
    </SubTitle>
  )
})

const styles = StyleSheet.create({
  list: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tip: {
    marginTop: 4,
  },
})
