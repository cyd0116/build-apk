import { updateSetting } from '@/core/common'
import { useI18n } from '@/lang'
import { createStyle } from '@/utils/tools'
import { memo } from 'react'
import { View } from 'react-native'
import { useSettingValue } from '@/store/setting/hook'

import CheckBoxItem from '../../components/CheckBoxItem'

/**
 * 定制功能：下载完成后自动添加到「我的收藏」
 */
export default memo(() => {
  const t = useI18n()
  const autoAddToLove = useSettingValue('download.autoAddToLove')
  const setAutoAddToLove = (value: boolean) => {
    requestAnimationFrame(() => {
      updateSetting({ 'download.autoAddToLove': value })
    })
  }

  return (
    <View style={styles.content}>
      <CheckBoxItem check={autoAddToLove} onChange={setAutoAddToLove} label={t('setting_download_auto_add_to_love')} />
    </View>
  )
})

const styles = createStyle({
  content: {
    marginTop: 5,
  },
})
