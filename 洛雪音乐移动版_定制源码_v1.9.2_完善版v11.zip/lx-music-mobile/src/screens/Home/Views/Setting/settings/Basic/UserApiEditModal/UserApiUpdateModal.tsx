import { forwardRef, useImperativeHandle, useRef, useState } from 'react'
import { View } from 'react-native'
import ConfirmAlert, { type ConfirmAlertType } from '@/components/common/ConfirmAlert'
import Input from '@/components/common/Input'
import Text from '@/components/common/Text'
import { useI18n } from '@/lang'
import { useTheme } from '@/store/theme/hook'
import { httpFetch } from '@/utils/request'
import { confirmDialog, createStyle, toast } from '@/utils/tools'
import { parseUserApiVersion } from '@/utils/data'
import { setUserApiUpdateUrl, updateUserApi } from '@/core/userApi'
import { setApiSource } from '@/core/apiSource'
import settingState from '@/store/setting/state'

export interface UserApiUpdateModalType {
  show: (item: LX.UserApi.UserApiInfo) => void
}

/**
 * 定制功能：自定义音源升级
 * - 记录脚本直链，之后从同一个入口一键检查更新
 * - 覆盖安装后保留音源 id / 更新提示开关，正在使用时自动重新加载脚本
 */
export default forwardRef<UserApiUpdateModalType, {}>((props, ref) => {
  const t = useI18n()
  const theme = useTheme()
  const alertRef = useRef<ConfirmAlertType>(null)
  const [visible, setVisible] = useState(false)
  const [item, setItem] = useState<LX.UserApi.UserApiInfo | null>(null)
  const [url, setUrl] = useState('')
  const [checking, setChecking] = useState(false)

  useImperativeHandle(ref, () => ({
    show(target) {
      setItem(target)
      setUrl(target.updateUrl ?? '')
      if (visible) alertRef.current?.setVisible(true)
      else {
        setVisible(true)
        requestAnimationFrame(() => {
          alertRef.current?.setVisible(true)
        })
      }
    },
  }))

  const handleConfirm = async() => {
    const target = item
    const link = url.trim()
    if (!target) return
    if (!/^https?:\/\//.test(link)) {
      toast(t('user_api_update_failed', { msg: 'invalid url' }), 'long')
      return
    }
    setChecking(true)
    try {
      // 先保存升级地址，下次可一键检查
      await setUserApiUpdateUrl(target.id, link)
      toast(t('user_api_update_url_saved'))
      const script = await httpFetch(link).promise.then(resp => resp.body) as string
      if (typeof script != 'string' || !/^\/\*/.test(script)) throw new Error('invalid script')

      const newVersion = parseUserApiVersion(script)
      const oldVersion = parseUserApiVersion(target.version)
      const isSame = !newVersion || !oldVersion || newVersion == oldVersion
      const confirmed = await confirmDialog({
        message: isSame
          ? t('user_api_update_same')
          : t('user_api_update_confirm', { old: oldVersion || '-', new: newVersion || '-' }),
        cancelButtonText: t('cancel_button_text_2'),
        confirmButtonText: isSame ? t('user_api_update_force') : t('confirm_button_text'),
        bgClose: false,
      })
      if (!confirmed) return

      await updateUserApi(target.id, script)
      // 正在使用该音源时重新加载脚本，使升级立即生效
      if (settingState.setting['common.apiSource'] == target.id) setApiSource(target.id)
      toast(t('user_api_update_success', { name: target.name, version: newVersion || target.version }))
      alertRef.current?.setVisible(false)
    } catch (err: any) {
      toast(t('user_api_update_failed', { msg: err?.message ?? String(err) }), 'long')
    } finally {
      setChecking(false)
    }
  }

  return (
    visible
      ? (
          <ConfirmAlert
            ref={alertRef}
            title={t('user_api_update_title')}
            onConfirm={() => { void handleConfirm() }}
            disabledConfirm={checking}
            confirmText={checking ? t('user_api_update_checking') : t('user_api_btn_update')}
          >
            <View style={styles.content}>
              <Text size={13} style={styles.tip}>{item?.name} · {item?.version}</Text>
              <Text size={12} style={styles.tip}>{t('user_api_update_url_tip')}</Text>
              <Input
                placeholder="https://..."
                value={url}
                onChangeText={setUrl}
                style={{ ...styles.input, backgroundColor: theme['c-primary-input-background'] }}
              />
            </View>
          </ConfirmAlert>
        )
      : null
  )
})

const styles = createStyle({
  content: {
    flexGrow: 1,
    flexShrink: 1,
    flexDirection: 'column',
  },
  tip: {
    marginBottom: 8,
  },
  input: {
    minWidth: 290,
    borderRadius: 4,
  },
})
