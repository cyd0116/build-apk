import { memo, useRef } from 'react'
import { Linking, Platform, View } from 'react-native'

import SubTitle from '../../components/SubTitle'
import Button from '../../components/Button'
import Text from '@/components/common/Text'
import ChoosePath, { type ChoosePathType } from '@/components/common/ChoosePath'
import { useI18n } from '@/lang'
import { useTheme } from '@/store/theme/hook'
import { useSettingValue } from '@/store/setting/hook'
import { updateSetting } from '@/core/common'
import { createStyle, toast } from '@/utils/tools'
import { DEFAULT_DOWNLOAD_DIR, FALLBACK_DOWNLOAD_DIR, getDownloadDir } from '@/core/music/downloadManager'

/**
 * 定制功能：下载歌曲的存储目录可选择，默认 Download/music
 * 复用项目自带的目录选择器（自带存储权限申请）
 */
export default memo(() => {
  const t = useI18n()
  const theme = useTheme()
  const savedDir = useSettingValue('download.dir')
  const choosePathRef = useRef<ChoosePathType>(null)
  const currentDir = getDownloadDir()
  const isDefault = !savedDir.trim()

  const saveDir = (dir: string) => {
    updateSetting({ 'download.dir': dir })
    toast(t('download_dir_saved', { dir: dir || DEFAULT_DOWNLOAD_DIR }))
  }

  const handleSelect = () => {
    choosePathRef.current?.show({
      title: t('setting_download_dir_select'),
      dirOnly: true,
    })
  }
  const handleReset = () => { saveDir('') }
  const handleInternal = () => { saveDir(FALLBACK_DOWNLOAD_DIR) }
  const openPermissionSetting = () => { void Linking.openSettings() }

  return (
    <SubTitle title={t('setting_download_dir')}>
      <Text size={12} numberOfLines={2} style={styles.path}>
        {isDefault ? `${t('download_default_label')}: ` : ''}{currentDir}
      </Text>
      <View style={styles.btns}>
        <Button onPress={handleSelect}>{t('setting_download_dir_select')}</Button>
        <Button onPress={handleReset}>{t('setting_download_dir_reset')}</Button>
      </View>
      <View style={styles.btns}>
        <Button onPress={handleInternal}>{t('setting_download_dir_internal')}</Button>
        {
          Platform.OS == 'android' && Number(Platform.Version) >= 30
            ? <Button onPress={openPermissionSetting}>{t('setting_download_dir_permission')}</Button>
            : null
        }
      </View>
      <Text size={11} color={theme['c-font-label']} style={styles.tip}>{t('setting_download_dir_tip')}</Text>
      <ChoosePath ref={choosePathRef} onConfirm={saveDir} />
    </SubTitle>
  )
})

const styles = createStyle({
  path: {
    marginBottom: 8,
  },
  btns: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 8,
  },
  tip: {
    marginTop: 2,
  },
})
