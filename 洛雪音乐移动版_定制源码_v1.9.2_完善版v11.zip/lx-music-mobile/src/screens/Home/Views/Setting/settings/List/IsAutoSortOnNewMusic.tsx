import { memo } from 'react'
import { StyleSheet, View } from 'react-native'

import CheckBoxItem from '../../components/CheckBoxItem'
import Text from '@/components/common/Text'
import { updateSetting } from '@/core/common'
import { useI18n } from '@/lang'
import { useSettingValue } from '@/store/setting/hook'
import { useTheme } from '@/store/theme/hook'

/**
 * 定制功能：设置页开关「新下载的歌曲自动按原排序规则排序」
 * - 开启：下载完成并加入列表后，整表按上次选定的排序规则重排（上一版行为）
 * - 关闭：新歌按默认位置插入，不自动重排
 */
export default memo(() => {
  const t = useI18n()
  const theme = useTheme()
  const enabled = useSettingValue('list.autoSortOnNewMusic')
  const setEnabled = (value: boolean) => {
    requestAnimationFrame(() => {
      updateSetting({ 'list.autoSortOnNewMusic': value })
    })
  }

  return (
    <View style={styles.content}>
      <CheckBoxItem check={enabled} onChange={setEnabled} label={t('setting_list_auto_sort_on_new_music')} />
      <Text size={11} color={theme['c-font-label']} style={styles.tip}>{t('setting_list_auto_sort_on_new_music_tip')}</Text>
    </View>
  )
})

const styles = StyleSheet.create({
  content: {
    marginTop: 5,
  },
  tip: {
    marginTop: 4,
  },
})
