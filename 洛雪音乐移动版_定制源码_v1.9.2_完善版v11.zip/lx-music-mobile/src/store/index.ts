

export const useGetter = () => {

}
