# LX Music 移动版 · 定制版（v1.9.2 源码）

本目录是基于 GitHub 官方仓库 `lyswhut/lx-music-mobile` 的 **v1.9.2** 标签源码修改后的完整工程。

## 已加入的功能

1. **歌曲下载 + 下载时选择音质**
   - 搜索结果 / 排行榜 / 歌单 / 在线歌单的歌曲菜单新增「下载」；多选模式下可批量下载。
   - 下载前弹出音质列表（128k / 320k / flac / flac24bit 等，按歌曲实际可用档位取交集）。
   - **默认保存到公共 `Download/music`**，目录可在设置里任意选择；写入公共目录前申请存储权限，不可写时自动回退到应用私有目录 `DocumentDir/Music`，保证下载不中断。
   - 同一首歌可保留多个音质版本，不覆盖；复用项目自带的 `react-native-fs`，**未新增任何 npm 依赖**。
2. **歌单删除歌曲时可选择「同时删除本地歌曲文件」**
   - 检测到本地文件（含本功能下载的歌曲、已导入的本地歌曲）时，默认弹出三选一：取消 / 仅从歌单移除 / 移除并删除本地文件。
   - 默认行为可在设置里改成「总是同时删除」或「仅从歌单移除」，不再每次弹窗（见第 8 条）。
3. **开关：下载完歌曲自动添加到「我的收藏」**（设置 → 列表设置）
4. **开关：下载时音质选择的默认选项**（设置 → 列表设置）
   - 128k / 320k / flac / flac24bit；音质弹窗中该档位高亮标注「默认」，并提供「使用默认音质」一键下载按钮。
5. **内置自定义音源：👖裤佬SVIP音源(二改整合版) v3.0.0**
   - 首次启动自动出现在「设置 → 基本设置 → 音乐来源 → 自定义源管理」列表中，并在未选择任何音源时自动启用。
   - 原脚本见 `assets/userApi/kulao-svip-v3.0.0.js`；已按移动端自定义源协议做兼容处理（补全 `@homepage`、POST body 改为对象以适配移动端自动 JSON 序列化、修正 pic 取参）。
   - 移动端自定义源运行时只透传 `musicUrl`，音质经运行时过滤为 128k / 320k / flac / flac24bit 四档，与本定制版的下载音质选择完全对应。
6. **自定义音源可升级**
   - 在线导入时会自动记住脚本直链。
   - 自定义源管理里每个音源新增「升级」按钮：可填写/修改脚本直链 → 检查更新 → 对比版本号 → 覆盖安装。
   - 升级保留音源 id、允许更新提示开关与升级地址；若该音源正在使用，升级后立即重新加载生效。
   - 音源脚本自身也可通过 `lx.send(EVENT_NAMES.updateAlert, ...)` 触发原有的更新提示。
7. **下载歌曲的存储目录可以选择，默认 Download/music**
   - 位置：设置 → 列表设置 → 下载歌曲的存储目录。
   - 「选择目录」复用应用内置目录浏览器（自动申请存储权限）；另有「恢复默认」「应用私有目录」「打开权限设置」（Android 11+）快捷按钮。
   - 下载记录保存的是文件**绝对路径**，更换目录后旧文件仍能被正确定位与删除。
   - Android 11+ 需在系统设置中开启「所有文件访问权限」才能写入公共 Download 目录（Manifest 已声明 `MANAGE_EXTERNAL_STORAGE`）；未开启时自动改存应用私有目录并提示。
8. **设置项：删除时「同时删除本地歌曲文件」**
   - 位置：设置 → 列表设置 → 删除歌曲时「同时删除本地歌曲文件」，三选一：**每次询问**（默认）/ **总是同时删除** / **仅从歌单移除**。
   - 选择后两项时不再弹出文件确认框；多选删除仍保留歌单移除确认。

## 主要改动文件

| 文件 | 说明 |
| --- | --- |
| `src/core/music/downloadManager.ts` | 下载、音质计算、可选下载目录（默认 Download/music）、权限与失败回退、下载记录、本地文件删除 |
| `src/components/MusicQualityModal/` | 音质选择弹窗（含默认档位） |
| `src/components/OnlineList/*`、`src/screens/Home/Views/Mylist/MusicList/*` | 菜单与下载/删除流程接入 |
| `src/screens/Home/Views/Setting/settings/List/DownloadDir.tsx` | 新增：下载目录选择设置项 |
| `src/screens/Home/Views/Setting/settings/List/DeleteLocalFileMode.tsx` | 新增：删除本地文件行为设置项 |
| `src/screens/Home/Views/Setting/settings/List/` | 其余设置项（自动收藏、默认音质等） |
| `src/config/defaultSetting.ts`、`src/types/app_setting.d.ts`、`src/lang/*.json` | 设置与多语言文案 |
| `src/utils/data.ts`、`src/core/userApi.ts` | 音源升级与升级地址持久化 |
| `src/core/init/userApi/index.ts`、`src/core/userApi/presetUserApi.ts` | 预置音源自动导入 |
| `src/screens/.../UserApiEditModal/UserApiUpdateModal.tsx` | 音源升级弹窗 |
| `android/app/src/main/AndroidManifest.xml` | 声明 `MANAGE_EXTERNAL_STORAGE`，供 Android 11+ 写入公共 Download 目录 |

## 打包 32 位（armeabi-v7a）APK

> 本工程内**没有**预编译 APK。当前执行环境缺少 Android SDK / NDK、JDK 17，且依赖下载被网络策略拦截，无法在此完成 Gradle 构建。请在装有 Android 开发环境的机器上按下面步骤操作，得到可直接安装的 32 位安装包。

### 环境要求

- Node.js 18+（官方 CI 用 20）、npm
- JDK **17**（官方 CI 用的是 Microsoft OpenJDK 17）
- Android SDK：Platform API 35/36、Build-Tools、NDK `26.1.10909125`
- 环境变量：`ANDROID_HOME` / `ANDROID_SDK_ROOT` 指向 SDK 目录；`JAVA_HOME` 指向 JDK 17
- Windows 用户注意：Gradle 缓存与临时目录路径不要包含中文（项目含 C++ 原生模块）

### 生成签名（release 包必需）

```bash
keytool -genkeypair -v -keystore android/app/lxmusic.keystore \
  -alias lxmusic -keyalg RSA -keysize 2048 -validity 10000
```

在 `android/keystore.properties` 中写入：

```properties
storeFile=lxmusic.keystore
storePassword=你的密码
keyAlias=lxmusic
keyPassword=你的密码
```

> 也可以像官方 CI 一样用 `-PMYAPP_UPLOAD_STORE_FILE=... -PMYAPP_UPLOAD_KEY_ALIAS=... -PMYAPP_UPLOAD_STORE_PASSWORD=... -PMYAPP_UPLOAD_KEY_PASSWORD=...` 传参，无需 `keystore.properties`。

### 只构建 32 位

直接运行一键脚本（会自动生成自测签名并锁定 armeabi-v7a）：

```bash
./build-32bit.sh
```

或手工执行：

```bash
npm ci
# 编辑 android/gradle.properties：reactNativeArchitectures=armeabi-v7a
cd android
./gradlew assembleRelease -PreactNativeArchitectures=armeabi-v7a
```

产物：

```
android/app/build/outputs/apk/release/lx-music-mobile-v1.9.2-armeabi-v7a.apk
```

安装到手机：

```bash
adb install -r android/app/build/outputs/apk/release/lx-music-mobile-v1.9.2-armeabi-v7a.apk
```

若构建报「中文路径 / 缓存」相关错误，按官方打包指南设置 `GRADLE_USER_HOME`、`TEMP`、`TMP` 到纯英文路径后重试。

## 合规提示

本项目为开源播放器，不含任何曲库；内置音源为第三方脚本，其可用性、合法性由使用者自行判断，请仅用于个人学习研究并遵守所在地区法律法规与音乐平台条款。定制版非官方发布版本。
