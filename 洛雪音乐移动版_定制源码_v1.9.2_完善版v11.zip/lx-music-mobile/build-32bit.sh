#!/usr/bin/env bash
# 一键构建 32 位（armeabi-v7a）release APK
# 运行前请自行安装：Node 18+、JDK 17、Android SDK(API 35)+NDK 26.1.10909125
set -euo pipefail
cd "$(dirname "$0")"

: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "$ANDROID_HOME" ]; then
  echo "请先设置 ANDROID_HOME / ANDROID_SDK_ROOT" >&2
  exit 1
fi
if ! command -v java >/dev/null 2>&1; then
  echo "未找到 java，请使用 JDK 17" >&2
  exit 1
fi

# 没有签名文件时自动创建（仅用于自测分发，正式发布请自行妥善保管密钥）
if [ ! -f android/keystore.properties ]; then
  echo "==> 生成自测签名"
  keytool -genkeypair -v -keystore android/app/lxmusic.keystore \
    -alias lxmusic -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass lxmusic123456 -keypass lxmusic123456 \
    -dname "CN=LX Music Custom, OU=Custom, O=Custom, L=SZ, ST=GD, C=CN" >/dev/null 2>&1
  cat > android/keystore.properties <<'EOF'
storeFile=lxmusic.keystore
storePassword=lxmusic123456
keyAlias=lxmusic
keyPassword=lxmusic123456
EOF
fi

# 只保留 32 位架构
python3 - <<'PY'
p = 'android/gradle.properties'
s = open(p, encoding='utf-8').read()
import re
if re.search(r'^reactNativeArchitectures=', s, re.M):
    s = re.sub(r'^reactNativeArchitectures=.*$', 'reactNativeArchitectures=armeabi-v7a', s, flags=re.M)
else:
    s += '\nreactNativeArchitectures=armeabi-v7a\n'
open(p, 'w', encoding='utf-8').write(s)
PY

echo "==> 安装依赖"
npm ci
echo "==> 构建 armeabi-v7a release"
(cd android && ./gradlew assembleRelease -PreactNativeArchitectures=armeabi-v7a)

APK=$(ls android/app/build/outputs/apk/release/*armeabi-v7a*.apk | head -n 1)
cp "$APK" "./$(basename "$APK")"
echo "==> 完成：./$(basename "$APK")"
echo "    安装：adb install -r ./$(basename "$APK")"
