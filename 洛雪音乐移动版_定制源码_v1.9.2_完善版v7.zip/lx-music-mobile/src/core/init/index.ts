import { initSetting } from '@/core/common'
import registerPlaybackService from '@/plugins/player/service'
import initTheme from './theme'
import initI18n from './i18n'
import initUserApi from './userApi'
import initPlayer from './player'
import dataInit from './dataInit'
import initSync from './sync'
import initCommonState from './common'
import { initDeeplink } from './deeplink'
import { setApiSource } from '@/core/apiSource'
import commonActions from '@/store/common/action'
import { bootLog } from '@/utils/bootLog'
import { syncListSortSettingIfChanged } from '@/utils/listSort'

// 定制功能：启动后直接进入主界面。
// 已移除「谨防被骗提示」「20 秒软件许可协议」「本软件完全免费且开源」以及
// 其它启动阶段的提示弹窗；仅保留与外链唤起相关的 deeplink 初始化。
let isFirstPush = true
const handlePushedHomeScreen = async() => {
  if (isFirstPush) {
    isFirstPush = false
    void initDeeplink()
  }
}

let isInited = false
export default async() => {
  if (isInited) return handlePushedHomeScreen
  bootLog('Initing...')
  commonActions.setFontSize(global.lx.fontSize)
  bootLog('Font size changed.')
  const setting = await initSetting()
  bootLog('Setting inited.')

  await initTheme(setting)
  bootLog('Theme inited.')
  await initI18n(setting)
  bootLog('I18n inited.')

  await initUserApi(setting)
  bootLog('User Api inited.')

  setApiSource(setting['common.apiSource'])
  bootLog('Api inited.')

  registerPlaybackService()
  bootLog('Playback Service Registered.')
  await initPlayer(setting)
  bootLog('Player inited.')
  await dataInit(setting)
  bootLog('Data inited.')
  // 定制功能：只在设定参数发生变化时重排一次；参数不变直接跳过，
  // 不读不写列表存储（列表里保存的就是排好的顺序，读取即保持）
  try {
    const sortChanged = await syncListSortSettingIfChanged()
    bootLog('List sort setting changed: ' + sortChanged)
  } catch (err: any) {
    bootLog('Sync list sort setting failed: ' + (err?.message ?? String(err)))
  }
  await initCommonState(setting)
  bootLog('Common State inited.')

  void initSync(setting)
  bootLog('Sync inited.')

  isInited ||= true

  return handlePushedHomeScreen
}
