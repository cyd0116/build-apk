import { memo } from 'react'
import { StyleSheet, View } from 'react-native'

import CheckBox from '@/components/common/CheckBox'
import CheckBoxItem from '../../components/CheckBoxItem'
import SubTitle from '../../components/SubTitle'
import Text from '@/components/common/Text'
import { updateSetting } from '@/core/common'
import { useI18n } from '@/lang'
import { useSettingValue } from '@/store/setting/hook'
import { useTheme } from '@/store/theme/hook'
import { applyListSortSettingToAllLists, getListSortSignature, markListSortSignature } from '@/utils/listSort'
import { toast } from '@/utils/tools'

const FIELDS = ['name', 'singer', 'album', 'time', 'source'] as const
const ORDERS = ['up', 'down'] as const

/**
 * 定制功能：列表歌曲排序方式（仅「我的收藏」与自建列表）
 * - 默认勾选：排序字段「歌曲名」、排序类别「升序」
 * - 设定一次即永久记忆：参数不变时启动不重排、不读写列表存储；
 *   只有在这里调整参数（或首次设定）才重排一次。
 */
export default memo(() => {
  const t = useI18n()
  const theme = useTheme()
  const enabled = useSettingValue('list.autoSortEnabled')
  const field = useSettingValue('list.sortField')
  const order = useSettingValue('list.sortType')

  // 调整参数才重排一遍；顺序未变化的列表内部会跳过，不产生无谓写入
  const reSort = () => {
    void applyListSortSettingToAllLists(true).then(num => {
      if (num) toast(t('setting_list_sort_applied_tip', { num }))
    })
  }
  const setEnabled = (value: boolean) => {
    requestAnimationFrame(() => {
      updateSetting({ 'list.autoSortEnabled': value })
      if (value) reSort()
      else void markListSortSignature(getListSortSignature())
    })
  }
  const setField = (value: typeof FIELDS[number]) => {
    requestAnimationFrame(() => {
      updateSetting({ 'list.sortField': value })
      reSort()
    })
  }
  const setOrder = (value: typeof ORDERS[number]) => {
    requestAnimationFrame(() => {
      updateSetting({ 'list.sortType': value })
      reSort()
    })
  }

  return (
    <SubTitle title={t('setting_list_sort_title')}>
      <CheckBoxItem check={enabled} onChange={setEnabled} label={t('setting_list_sort_enable')} />
      <Text size={11} color={theme['c-font-label']} style={styles.tip}>{t('setting_list_sort_tip')}</Text>
      <Text size={13} style={styles.label}>{t('list_sort_modal_by_field')}</Text>
      <View style={styles.list}>
        {
          FIELDS.map(f => (
            <CheckBox
              key={f}
              marginRight={8}
              check={field == f}
              label={t(`list_sort_modal_by_${f}`)}
              onChange={() => { setField(f) }}
              need />
          ))
        }
      </View>
      <Text size={13} style={styles.label}>{t('list_sort_modal_by_type')}</Text>
      <View style={styles.list}>
        {
          ORDERS.map(o => (
            <CheckBox
              key={o}
              marginRight={8}
              check={order == o}
              label={t(`list_sort_modal_by_${o}`)}
              onChange={() => { setOrder(o) }}
              need />
          ))
        }
      </View>
    </SubTitle>
  )
})

const styles = StyleSheet.create({
  tip: {
    marginTop: 4,
    marginBottom: 8,
  },
  label: {
    marginBottom: 6,
  },
  list: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 8,
  },
})
